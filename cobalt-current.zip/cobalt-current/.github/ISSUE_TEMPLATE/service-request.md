---
name: service request
about: request service support in cobalt
title: 'add support for [service name]'
labels: service request
assignees: ''

---

### service name & description
provide the service name and brief description of what it is.

### link samples for the service you'd like cobalt to support
list of links that cobalt should recognize. 
could be regular video link, shared video link, mobile video link, shortened link, etc.

### additional context
any additional context or screenshots should go here. if there aren't any, just remove this part.
