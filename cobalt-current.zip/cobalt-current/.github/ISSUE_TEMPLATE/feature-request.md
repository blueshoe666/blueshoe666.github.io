---
name: feature request
about: suggest a feature for cobalt
title: '[short feature request description]'
labels: feature request
assignees: ''

---

### describe the feature you'd like to see
clear and concise description of the feature you want to see in cobalt.

### additional context
if applicable, add any other context or screenshots related to the feature request here.  
if not, remove this section.
